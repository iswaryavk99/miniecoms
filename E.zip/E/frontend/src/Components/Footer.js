export default function Footer(){
    return  <footer className="py-1">
    <p className="text-center text-white mt-1 ">
      iswaryavk99@gmail.com - All Rights Reserved - 2025
    </p>
  </footer>

}   